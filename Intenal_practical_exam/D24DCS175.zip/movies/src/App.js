import React, { useState } from 'react';
import './App.css';

function App() {
  const movieData = {
    "The Shawshank Redemption": 9.3,
    "The Godfather": 9.2,
    "The Dark Knight": 9.0,
    "Pulp Fiction": 8.9,
    "The Lord of the Rings: The Return of the King": 8.9
  };

  const [movie, setMovie] = useState('');
  const [rating, setRating] = useState(null);
  const [message, setMessage] = useState('');

  const getMovieRating = () => {
    if (movie in movieData) {
      setRating(movieData[movie]);
      setMessage('');
    } else {
      setRating(null);
      setMessage(`Rating data for "${movie}" is not found.`);
    }
  };

  return (
    <div className="movie-app">
      <h2>Movie App</h2>
      <input
        type="text"
        placeholder="Enter movie"
        value={movie}
        onChange={(e) => setMovie(e.target.value)}
      />
      <button onClick={getMovieRating}>Click here to Get Movie Rating</button>
      {rating !== null && (
        <p>The rating of {movie} is {rating}</p>
      )}
      {message && <p>{message}</p>}
    </div>
  );
}

export default App;
