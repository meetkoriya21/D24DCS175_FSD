const getMoviesBtn = document.getElementById('getMoviesBtn');
const movieResult = document.getElementById('movieResult');
const movieInput = document.getElementById('movieInput');
const suggestions = document.getElementById('suggestions');

const apiKey = '5b9264b6961e9d82d7dd7a58b06671d3'; // User provided TheMovieDB API key

let selectedMovie = '';

async function fetchMovies(movie) {
  try {
    const response = await fetch(`https://api.themoviedb.org/3/search/movie?api_key=${apiKey}&query=${movie}`, {
    method: 'GET',
    headers: {
        'Content-Type': 'application/json'
    }
});

const data = await response.json();
console.log(data);

    return {
      temp: data.results[0].vote_average,
      description: data.results[0].overview,
      humidity: data.results[0].vote_count,
      windSpeed: data.results[0].popularity
    };
  } catch (error) {
    return null;
  }
}

async function displayMovies(movie) {
  const movies = await fetchMovies(movie);
  if (movies !== null) {
    movieResult.innerHTML = `
      <p>The movie <strong>${movie}</strong> has a rating of <strong>${movies.temp}°C</strong></p>
      <p><strong>Description:</strong> ${movies.description}</p>
      <p><strong>Vote Count:</strong> ${movies.humidity}</p>
      <p><strong>Popularity:</strong> ${movies.windSpeed}</p>
    `;
  } else {
    movieResult.textContent = "Movie data for \"" + movie + "\" is not found.";
  }
}

function clearSuggestions() {
  suggestions.innerHTML = '';
  suggestions.style.display = 'none';
}

function showSuggestions(matches) {
  clearSuggestions();
  if (matches.length === 0) return;
  suggestions.style.display = 'block';
  matches.forEach(movie => {
    const div = document.createElement('div');
    div.textContent = movie;
    div.classList.add('suggestion-item');
    div.addEventListener('click', () => {
      cityInput.value = movie;
      selectedMovie = movie;
      clearSuggestions();
      displayMovies(movie);  // Show movies immediately on suggestion click
    });
    suggestions.appendChild(div);
  });
}

movieInput.addEventListener('input', () => {
  const input = movieInput.value.toLowerCase();
  if (!input) {
    clearSuggestions();
    return;
  }
  const matches = movies.filter(movie => movie.toLowerCase().startsWith(input));
  showSuggestions(matches);
});

getMoviesBtn.addEventListener('click', () => {
  const movie = selectedMovie || movieInput.value;
  if (movie) {
    displayMovies(movie);
  }
});

// Display movies for a default movie on initial load
window.onload = () => {
  selectedMovie = 'Avengers';
  movieInput.value = selectedMovie;
  displayMovies(selectedMovie);
};
